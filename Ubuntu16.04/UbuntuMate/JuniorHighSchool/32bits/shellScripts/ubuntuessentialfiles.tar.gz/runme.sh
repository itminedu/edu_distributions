#!/bin/sh

mkdir /home/student/EducationSoftware
mkdir /home/student/EducationSoftware/Icons
mkdir /home/student/EducationSoftware/MolecularWorkbench
mkdir /home/student/EducationSoftware/FlashPlayer
chown student:student /home/student/EducationSoftware
chown student:student /home/student/EducationSoftware/Icons
chown student:student /home/student/EducationSoftware/MolecularWorkbench
chown student:student /home/student/EducationSoftware/FlashPlayer

cp /home/student/InitialFiles/lightbot-icon-152jr.png /home/student/EducationSoftware/Icons/lightbot-icon-152jr.png
cp /home/student/InitialFiles/xmind.png /home/student/EducationSoftware/Icons/xmind.png
cp /home/student/InitialFiles/asymptopia.png /home/student/EducationSoftware/Icons/asymptopia.png
cp /home/student/InitialFiles/url.png /home/student/EducationSoftware/Icons/url.png
cp /home/student/InitialFiles/mw.png /home/student/EducationSoftware/Icons/mw.png
cp /home/student/InitialFiles/edutv.png /home/student/EducationSoftware/Icons/edutv.png
cp /home/student/InitialFiles/sne.png /home/student/EducationSoftware/Icons/sne.png
cp /home/student/InitialFiles/storybird.png /home/student/EducationSoftware/Icons/storybird.png

cp /home/student/InitialFiles/bedtime.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/edutv.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/sne.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/storybird.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/mw.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/aesopos.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/golab.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/timeline.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/timeglider.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/zunal.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/phet.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/asymptopia.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/Xmind.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/libreofficewriter.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/libreofficecalc.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/vlc.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/filezilla.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/firefox.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/audacity.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/openshot.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/k3b.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/lightbot.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/ubuntu-software-center.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/skype.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/gimp.desktop "/home/student/Επιφάνεια εργασίας"

chmod +x "/home/student/Επιφάνεια εργασίας/bedtime.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/edutv.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/sne.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/storybird.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/mw.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/aesopos.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/golab.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/timeline.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/timeglider.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/zunal.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/phet.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/asymptopia.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/Xmind.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/libreofficewriter.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/libreofficecalc.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/vlc.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/filezilla.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/firefox.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/audacity.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/openshot.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/k3b.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/lightbot.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/ubuntu-software-center.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/skype.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/gimp.desktop"

uxterm -e "sudo gpasswd -a student epoptes ; gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ size 20 ; gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ size 20 ; gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ orientation bottom ; gsettings set org.mate.caja.desktop computer-icon-visible true ; gsettings set org.mate.caja.desktop home-icon-visible true ; gsettings set org.mate.caja.desktop network-icon-visible true ; gsettings set org.mate.caja.desktop trash-icon-visible true ; gsettings set org.mate.Marco.general center-new-windows true"
uxterm -e "wget -O /home/student/EducationSoftware/flash_player_npapi_linux.i386.tar.gz http://ostdev.minedu.gov.gr/~kotsimp/customDistros/JuniorHighSchool/flash_player_npapi_linux.i386.tar.gz ; tar xvf /home/student/EducationSoftware/flash_player_npapi_linux.i386.tar.gz -C  /home/student/EducationSoftware/FlashPlayer ; sudo cp /home/student/EducationSoftware/FlashPlayer/libflashplayer.so /usr/lib/mozilla/plugins ; sudo cp -r /home/student/EducationSoftware/FlashPlayer/usr/* /usr"
uxterm -e "wget -O /home/student/EducationSoftware/MolecularWorkbench/mw.jar http://ostdev.minedu.gov.gr/~kotsimp/customDistros/JuniorHighSchool/mw.jar ; wget -O /home/student/EducationSoftware/xmind-8-linux.zip http://ostdev.minedu.gov.gr/~kotsimp/customDistros/JuniorHighSchool/xmind-8-linux.zip ; unzip -o /home/student/EducationSoftware/xmind-8-linux.zip -d /home/student/EducationSoftware/Xmind ; sudo /home/student/EducationSoftware/Xmind/setup.sh ; sudo apt-get update ; sudo apt-get -y --force-yes install oracle-java8-installer ; sudo /home/student/InitialFiles/tsrepo.sh ; sudo apt-get -y --force-yes install skype ; sudo apt-get -y --force-yes install gecko-mediaplayer ; sudo apt-get -y --force-yes install wine-el ; sudo apt-get -y --force-yes install palapeli ; sudo apt-get -y --force-yes install kollision ; sudo apt-get -y --force-yes install kapman ; rm /home/student/.config/autostart/RunME.desktop"
uxterm -e "wget -O /home/student/EducationSoftware/AsymptopiaXW-3.2.zip http://ostdev.minedu.gov.gr/~kotsimp/customDistros/JuniorHighSchool/AsymptopiaXW-3.2.zip ; unzip -o /home/student/EducationSoftware/AsymptopiaXW-3.2.zip -d /home/student/EducationSoftware/AsymptopiaXW"
uxterm -e "sudo apt-get -y --force-yes install inkscape ; sudo apt-get -y --force-yes install gym-microworlds-c ; sudo apt-get -y --force-yes install pidgin  ; sudo apt-get -y --force-yes install object-karel ; sudo apt-get -y --force-yes install gym-chelonokosmoi ; sudo apt-get -y --force-yes install mortran ; sudo apt-get -y --force-yes install starlogotng ; sudo apt-get -y --force-yes install ekiga ; sudo apt-get -y --force-yes install gym-ksenios ; sudo apt-get -y --force-yes install karel ; sudo apt-get -y --force-yes install glossa ; sudo apt-get -y --force-yes install starlogo"
uxterm -e "sudo apt-get -y --force-yes install gymnasio ; sudo apt-get -y --force-yes install gym-mykinaikos-politismos gym-taxinomoume gym-metanastes"
uxterm -e "sudo apt-get -y --force-yes install apt-transport-https ; sudo apt-get -y --force-yes install --reinstall ttf-mscorefonts-installer ; sudo apt-get -y --force-yes install ibus-gtk ibus-gtk3 ; sudo apt-get -y --force-yes install software-center"
uxterm -e "wget -O /home/student/EducationSoftware/skype-ubuntu-precise_i386.deb http://ostdev.minedu.gov.gr/~kotsimp/customDistros/JuniorHighSchool/skype-ubuntu-precise_i386.deb ; sudo dpkg --add-architecture i386 ; sudo apt-get update ; sudo dpkg -i /home/student/EducationSoftware/skype-ubuntu-precise_i386.deb ; sudo apt-get -y --force-yes -f install"
uxterm -e "sudo gsettings set org.freedesktop.ibus.general use-system-keyboard-layout true ; sudo gsettings set org.freedesktop.ibus.panel show-icon-on-systray false ; sudo dpkg --configure -a ; sudo /bin/sh /home/student/InitialFiles/keys.sh ; reboot"

