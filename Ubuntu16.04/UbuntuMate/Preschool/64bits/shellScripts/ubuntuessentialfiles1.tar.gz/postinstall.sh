#!/bin/sh

mkdir /home/student/InitialFiles
chown student:student /home/student/InitialFiles

cp /tmp/fungooms.png /home/student/InitialFiles ; \
cp /tmp/ktuberling.png /home/student/InitialFiles ; \
cp /tmp/lightbot-icon-152jr.png /home/student/InitialFiles ; \
cp /tmp/fountoulis.jpg /home/student/InitialFiles ; \
cp /tmp/kourdista.jpg /home/student/InitialFiles ; \
cp /tmp/thenumberrace.png /home/student/InitialFiles ; \

cp /tmp/thenumberrace.desktop /home/student/InitialFiles/thenumberrace.desktop ; \
cp /tmp/Fungooms.desktop /home/student/InitialFiles/Fungooms.desktop ; \
cp /tmp/Antonakis.desktop /home/student/InitialFiles/Antonakis.desktop ; \
cp /tmp/gcompris.desktop /home/student/InitialFiles/gcompris.desktop ; \
cp /tmp/tuxpaint.desktop /home/student/InitialFiles/tuxpaint.desktop ; \
cp /tmp/tuxtype.desktop /home/student/InitialFiles/tuxtype.desktop ; \
#cp /tmp/tuxguitar.desktop /home/student/InitialFiles/tuxguitar.desktop ; \
cp /tmp/libreofficewriter.desktop /home/student/InitialFiles/libreofficewriter.desktop ; \
cp /tmp/libreofficecalc.desktop /home/student/InitialFiles/libreofficecalc.desktop ; \
cp /tmp/vlc.desktop /home/student/InitialFiles/vlc.desktop ; \
cp /tmp/filezilla.desktop /home/student/InitialFiles/filezilla.desktop ; \
cp /tmp/firefox.desktop /home/student/InitialFiles/firefox.desktop ; \
cp /tmp/audacity.desktop /home/student/InitialFiles/audacity.desktop ; \
cp /tmp/openshot.desktop /home/student/InitialFiles/openshot.desktop ; \
cp /tmp/pysiogame.desktop /home/student/InitialFiles/pysiogame.desktop ; \
cp /tmp/childsplay.desktop /home/student/InitialFiles/childsplay.desktop ; \  
#cp /tmp/tuxfootball.desktop /home/student/InitialFiles/tuxfootball.desktop ; \
cp /tmp/extremetuxracer.desktop /home/student/InitialFiles/extremetuxracer.desktop ; \
cp /tmp/blinken.desktop /home/student/InitialFiles/blinken.desktop ; \
cp /tmp/gimp.desktop /home/student/InitialFiles/gimp.desktop ; \
cp /tmp/k3b.desktop /home/student/InitialFiles/k3b.desktop ; \
#cp /tmp/kapman.desktop /home/student/InitialFiles/kapman.desktop ; \
cp /tmp/ktuberling.desktop /home/student/InitialFiles/ktuberling.desktop ; \
#cp /tmp/kblocks.desktop /home/student/InitialFiles/kblocks.desktop ; \
#cp /tmp/kollision.desktop /home/student/InitialFiles/kollision.desktop ; \
cp /tmp/lightbot.desktop /home/student/InitialFiles/lightbot.desktop ; \
cp /tmp/mathaino_ti_glossa_mou.desktop /home/student/InitialFiles/mathaino_ti_glossa_mou.desktop ; \
cp /tmp/kourdista.desktop /home/student/InitialFiles/kourdista.desktop ; \
#cp /tmp/Home.desktop /home/student/InitialFiles/Home.desktop ; \
#cp /tmp/trash.desktop /home/student/InitialFiles/trash.desktop ; \
cp /tmp/ubuntu-software-center.desktop /home/student/InitialFiles/ubuntu-software-center.desktop ; \
cp /tmp/skype.desktop /home/student/InitialFiles/skype.desktop ; \
  
chown student:student /home/student/InitialFiles/fungooms.png ;\
chown student:student /home/student/InitialFiles/ktuberling.png ;\
chown student:student /home/student/InitialFiles/lightbot-icon-152jr.png ;\
chown student:student /home/student/InitialFiles/fountoulis.jpg ;\
chown student:student /home/student/InitialFiles/kourdista.jpg ;\
chown student:student /home/student/InitialFiles/thenumberrace.png ;\

chown student:student /home/student/InitialFiles/thenumberrace.desktop ;\
chown student:student /home/student/InitialFiles/Fungooms.desktop ;\
chown student:student /home/student/InitialFiles/Antonakis.desktop ;\
chown student:student /home/student/InitialFiles/ktuberling.desktop ;\
chown student:student /home/student/InitialFiles/gcompris.desktop ; \
chown student:student /home/student/InitialFiles/tuxpaint.desktop ; \
chown student:student /home/student/InitialFiles/tuxtype.desktop ; \
#chown student:student /home/student/InitialFiles/tuxguitar.desktop ; \
chown student:student /home/student/InitialFiles/libreofficewriter.desktop ; \
chown student:student /home/student/InitialFiles/libreofficecalc.desktop ; \
chown student:student /home/student/InitialFiles/vlc.desktop ; \
chown student:student /home/student/InitialFiles/filezilla.desktop ; \
chown student:student /home/student/InitialFiles/firefox.desktop ; \
chown student:student /home/student/InitialFiles/audacity.desktop ; \
chown student:student /home/student/InitialFiles/openshot.desktop ; \
chown student:student /home/student/InitialFiles/pysiogame.desktop ; \
chown student:student /home/student/InitialFiles/childsplay.desktop ; \
#chown student:student /home/student/InitialFiles/tuxfootball.desktop ; \
chown student:student /home/student/InitialFiles/extremetuxracer.desktop ; \
chown student:student /home/student/InitialFiles/blinken.desktop ; \
chown student:student /home/student/InitialFiles/gimp.desktop ; \
chown student:student /home/student/InitialFiles/k3b.desktop ; \
#chown student:student /home/student/InitialFiles/kapman.desktop ; \
chown student:student /home/student/InitialFiles/ktuberling.desktop ; \
#chown student:student /home/student/InitialFiles/kblocks.desktop ; \
#chown student:student /home/student/InitialFiles/kollision.desktop ; \
chown student:student /home/student/InitialFiles/lightbot.desktop ; \
chown student:student /home/student/InitialFiles/mathaino_ti_glossa_mou.desktop ; \
chown student:student /home/student/InitialFiles/kourdista.desktop ; \
#chown student:student /home/student/InitialFiles/Home.desktop ; \
#chown student:student /home/student/InitialFiles/trash.desktop ; \
chown student:student /home/student/InitialFiles/ubuntu-software-center.desktop ; \
chown student:student /home/student/InitialFiles/skype.desktop ; \
  
chmod +x /home/student/InitialFiles/*.desktop ; \

echo "deb http://ppa.launchpad.net/webupd8team/java/ubuntu xenial main" | tee /etc/apt/sources.list.d/webupd8team-java.list ; \
echo "deb-src http://ppa.launchpad.net/webupd8team/java/ubuntu xenial main" | tee -a /etc/apt/sources.list.d/webupd8team-java.list ; \

mv /tmp/keys.sh /home/student/InitialFiles ; \
chmod +x /home/student/InitialFiles/keys.sh ; \

cp /tmp/tsrepo.sh /home/student/InitialFiles ; \
chown student:student /home/student/InitialFiles/tsrepo.sh ; \
chmod +x /home/student/InitialFiles/tsrepo.sh ; \

mkdir /home/student/.config/autostart ; \
chown -R student:student /home/student/.config/autostart/ ; \
cp /home/student/RunME.desktop /home/student/.config/autostart/RunME.desktop ; \
chown student:student /home/student/.config/autostart/RunME.desktop ; \
chmod +x /home/student/.config/autostart/RunMe.desktop ; \

mv /home/student/runme.sh /home/student/InitialFiles
mv /home/student/RunME.desktop /home/student/InitialFiles

/bin/cp -f /tmp/freedesktop.org.xml /usr/share/mime/packages/freedesktop.org.xml

pip install PyMsgBox

touch /root/preschool64
