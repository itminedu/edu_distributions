#!/bin/sh
mkdir /home/student/EducationSoftware
mkdir /home/student/photo
mkdir /home/student/EducationSoftware/FlashPlayer
cd /home/student

#mkdir "/home/student/Επιφάνεια εργασίας/Υγεία"
cp /home/student/nut.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/nut.desktop"

cp /home/student/biodigital.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/biodigital.desktop"

cp /home/student/hybrid.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/hybrid.desktop"

cp /home/student/innerbody.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/innerbody.desktop"

cp /home/student/zygotebody.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/zygotebody.desktop"

#cp /home/student/audacity.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/audacity.desktop"

cp /home/student/firefox.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/firefox.desktop"

#cp /home/student/k3b.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/k3b.desktop"
#cp /home/student/libreofficecalc.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/libreofficecalc.desktop"
#cp /home/student/libreofficeimpress.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/libreofficeimpress.desktop"
#cp /home/student/libreofficewriter.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/libreofficewriter.desktop"

#cp /home/student/openshot.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/openshot.desktop"

#cp /home/student/scratch.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/scratch.desktop"

cp /home/student/vlc.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/vlc.desktop"

#cp /home/student/lmms.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/lmms.desktop"
#cp /home/student/audacious.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/audacious.desktop"
#cp /home/student/linphone.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/linphone.desktop"
#cp /home/student/blender.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/blender.desktop"
#cp /home/student/geany.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/geany.desktop"
#cp /home/student/greenfoot.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/greenfoot.desktop"
#cp /home/student/geogebra.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/geogebra.desktop"

cp /home/student/netbeans.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/netbeans.desktop"

cp /home/student/dia.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/dia.desktop"

#cp /home/student/dolibarr.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/dolibarr.desktop"

cp /home/student/gimp.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/gimp.desktop"

cp /home/student/librecad.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/librecad.desktop"

cp /home/student/falstad.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/falstad.desktop"

cp /home/student/Sublime.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/Sublime.desktop"

cp /home/student/seamonkey.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/seamonkey.desktop"

cp /home/student/biodigital.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/biodigital.desktop"

cp /home/student/hybrid.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/hybrid.desktop"

cp /home/student/innerbody.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/innerbody.desktop"

cp /home/student/zygotebody.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/zygotebody.desktop"

cp /home/student/Sublime.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/Sublime.desktop"

cp /home/student/Redmine.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/Redmine.desktop"

cp /home/student/core.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/core.desktop"

cp /home/student/ubuntu-software-center.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/ubuntu-software-center.desktop"

cp /home/student/skype.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/skype.desktop"

uxterm -e "sudo gpasswd -a student epoptes ; gsettings set org.mate.SettingsDaemon.plugins.keyboard active true; gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ size 20; gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ size 20; gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ orientation bottom; gsettings set org.mate.caja.desktop computer-icon-visible true; gsettings set org.mate.caja.desktop home-icon-visible true; gsettings set org.mate.caja.desktop network-icon-visible true; gsettings set org.mate.caja.desktop trash-icon-visible true; gsettings set org.mate.Marco.general center-new-windows true"

uxterm -e "wget -O /home/student/EducationSoftware/FlashPlayer/flash_player_npapi_linux.x86_64.tar.gz http://ostdev.minedu.gov.gr/~sofiakom/customDistros/HighSchoolEdition/flash_player_npapi_linux.x86_64.tar.gz ; tar xvf /home/student/EducationSoftware/FlashPlayer/flash_player_npapi_linux.x86_64.tar.gz -C  /home/student/EducationSoftware/FlashPlayer ; sudo cp /home/student/EducationSoftware/FlashPlayer/libflashplayer.so /usr/lib/mozilla/plugins ; sudo cp -r /home/student/EducationSoftware/FlashPlayer/usr/* /usr"

uxterm -e "wget http://ostdev.minedu.gov.gr/~afpapag/CustomDistros/EpalEdition/sublime_text_3_build_x64.tar.bz2; tar xjvf /home/student/sublime_text_3_build_x64.tar.bz2; 
mv /home/student/sublime_text_3 /home/student/EducationSoftware; 

wget http://ostdev.minedu.gov.gr/~pgeorg/customDistros/developerEdition/netbeans-8.1-linux.sh /home/student; chmod +x /home/student/netbeans-8.1-linux.sh; 
mv /home/student/netbeans-8.1-linux.sh /home/student/EducationSoftware; 

wget http://ostdev.minedu.gov.gr/~afpapag/CustomDistros/EpalEdition/aoi.zip /home/student/; 

wget http://ftp.mozilla.org/pub/mozilla.org/seamonkey/releases/2.33/contrib/seamonkey-2.33.en-US.linux-x86_64.tar.bz2; 


wget http://downloads.pf.itd.nrl.navy.mil/core/packages/4.8/core-daemon_4.8-0ubuntu1_precise_amd64.deb /home/student/core-daemon_4.8-0ubuntu1_precise_amd64.deb; 

wget http://downloads.pf.itd.nrl.navy.mil/core/packages/4.8/core-gui_4.8-0ubuntu1_precise_all.deb /home/student/core-gui_4.8-0ubuntu1_precise_all.deb; 

sudo apt-get update;
sudo apt-get -y --allow-unauthenticated install oracle-java8-installer; 

sudo apt-get -y install scribus-ng; 

sudo apt-get -y install hoteldruid;
sudo apt-get -y install kmymoney;

sudo apt-get -y install qgis python-qgis qgis-plugin-grass; 
sudo apt-get update; sudo apt-get -y install qgis
sudo apt-get purge gnucash; sudo apt-get update; sudo apt-get -y install gnucash;

sudo apt-get -y install r-base; sudo apt-get -y install r-base-dev; 

sudo apt-get -y install core-network; 
sudo apt-get -y install quagga;  

tar -jxvf seamonkey-2.33.en-US.linux-x86_64.tar.bz2; 

sudo apt-get -y install nut-nutrition;

unzip /home/student/aoi.zip; 
java -jar AOI-Linux-303.jar; 

sudo apt-get -y install skype;
sudo apt-get -y install wine-el"

uxterm -e "rm /home/student/.config/autostart/RunME.desktop"

uxterm -e "sudo apt-get -y --force-yes install apt-transport-https ; sudo apt-get -y --force-yes install --reinstall ttf-mscorefonts-installer ; sudo apt-get -y --force-yes install ibus-gtk ibus-gtk3 ; sudo apt-get -y --force-yes install software-center"

uxterm -e "sudo gsettings set org.freedesktop.ibus.general use-system-keyboard-layout true; sudo gsettings set org.freedesktop.ibus.panel show-icon-on-systray false; sudo dpkg --configure -a; reboot"

#sudo apt-get dist-upgrade; sudo apt-get -y install bash bridge-utils ebtables iproute libev-dev python tcl8.5 tk8.5 libtk-img; sudo dpkg -i core-daemon_4.8-0ubuntu1_precise_amd64.deb; sudo dpkg -i core-gui_4.8-0ubuntu1_precise_all.deb;

