#!/bin/sh
mkdir /home/student/InitialFiles
chown student:student /home/student/InitialFiles

cp /tmp/core.sh /home/student/core.sh
chown student:student /home/student/core.sh

cp /tmp/nut.png /home/student/nut.png
chown student:student /home/student/nut.png

cp /tmp/falstad.png /home/student/falstad.png
chown student:student /home/student/falstad.png

cp /tmp/seamonkey.png /home/student/seamonkey.png
chown student:student /home/student/seamonkey.png

cp /tmp/redmine.png /home/student/redmine.png
chown student:student /home/student/redmine.png

cp /tmp/sublime.png /home/student/sublime.png
chown student:student /home/student/sublime.png

#cp /tmp/eol.png /home/student/eol.png
#chown student:student /home/student/eol.png

cp /tmp/biodigital.png /home/student/biodigital.png
chown student:student /home/student/biodigital.png

cp /tmp/hybrid.png /home/student/hybrid.png
chown student:student /home/student/hybrid.png

cp /tmp/innerbody.png /home/student/innerbody.png
chown student:student /home/student/innerbody.png

cp /tmp/zygotebody.png /home/student/zygotebody.png
chown student:student /home/student/zygotebody.png

cp /tmp/falstad.desktop /home/student/falstad.desktop
chown student:student /home/student/falstad.desktop
chmod +x /home/student/falstad.desktop

cp /tmp/kicad.desktop /home/student/kicad.desktop
chown student:student /home/student/kicad.desktop
chmod +x /home/student/kicad.desktop

cp /tmp/freecad.desktop /home/student/freecad.desktop
chown student:student /home/student/freecad.desktop
chmod +x /home/student/freecad.desktop

#cp /tmp/eol.desktop /home/student/eol.desktop
#chown student:student /home/student/eol.desktop
#chmod +x /home/student/eol.desktop

cp /tmp/biodigital.desktop /home/student/biodigital.desktop
chown student:student /home/student/biodigital.desktop
chmod +x /home/student/biodigital.desktop

cp /tmp/hybrid.desktop /home/student/hybrid.desktop
chown student:student /home/student/hybrid.desktop
chmod +x /home/student/hybrid.desktop

cp /tmp/innerbody.desktop /home/student/innerbody.desktop
chown student:student /home/student/innerbody.desktop
chmod +x /home/student/innerbody.desktop

cp /tmp/zygotebody.desktop /home/student/zygotebody.desktop
chown student:student /home/student/zygotebody.desktop
chmod +x /home/student/zygotebody.desktop

#cp /tmp/audacity.desktop /home/student/audacity.desktop
#chown student:student /home/student/audacity.desktop
#chmod +x /home/student/audacity.desktop

#cp /tmp/greenfoot.desktop /home/student/greenfoot.desktop
#chown student:student /home/student/greenfoot.desktop
#chmod +x /home/student/greenfoot.desktop

cp /tmp/firefox.desktop /home/student/firefox.desktop
chown student:student /home/student/firefox.desktop
chmod +x /home/student/firefox.desktop

#cp /tmp/k3b.desktop /home/student/k3b.desktop
#chown student:student /home/student/k3b.desktop
#chmod +x /home/student/k3b.desktop
#cp /tmp/libreofficecalc.desktop /home/student/libreofficecalc.desktop
#chown student:student /home/student/libreofficecalc.desktop
#chmod +x /home/student/libreofficecalc.desktop
#cp /tmp/libreofficeimpress.desktop /home/student/libreofficeimpress.desktop
#chown student:student /home/student/libreofficeimpress.desktop
#chmod +x /home/student/libreofficeimpress.desktop
#cp /tmp/libreofficewriter.desktop /home/student/libreofficewriter.desktop
#chown student:student /home/student/libreofficewriter.desktop
#chmod +x /home/student/libreofficewriter.desktop
#cp /tmp/openshot.desktop /home/student/openshot.desktop
#chown student:student /home/student/openshot.desktop
#chmod +x /home/student/openshot.desktop

cp /tmp/vlc.desktop /home/student/vlc.desktop
chown student:student /home/student/vlc.desktop
chmod +x /home/student/vlc.desktop

#cp /tmp/lmms.desktop /home/student/lmms.desktop
#chown student:student /home/student/lmms.desktop
#chmod +x /home/student/lmms.desktop

#cp /tmp/audacious.desktop /home/student/audacious.desktop
#chown student:student /home/student/audacious.desktop
#chmod +x /home/student/audacious.desktop
#cp /tmp/linphone.desktop /home/student/linphone.desktop
#chown student:student /home/student/linphone.desktop
#chmod +x /home/student/linphone.desktop
#cp /tmp/blender.desktop /home/student/blender.desktop
#chown student:student /home/student/blender.desktop
#chmod +x /home/student/blender.desktop
#cp /tmp/geany.desktop /home/student/geany.desktop
#chown student:student /home/student/geany.desktop
#chmod +x /home/student/geany.desktop

cp /tmp/Sublime.desktop /home/student/Sublime.desktop
chown student:student /home/student/Sublime.desktop
chmod +x /home/student/Sublime.desktop

cp /tmp/netbeans.desktop /home/student/netbeans.desktop
chown student:student /home/student/netbeans.desktop
chmod +x /home/student/netbeans.desktop

cp /tmp/dia.desktop /home/student/dia.desktop
chown student:student /home/student/dia.desktop
chmod +x /home/student/dia.desktop

#cp /tmp/dolibarr.desktop /home/student/dolibarr.desktop
#chown student:student /home/student/dolibarr.desktop
#chmod +x /home/student/dolibarr.desktop

cp /tmp/gimp.desktop /home/student/gimp.desktop
chown student:student /home/student/gimp.desktop
chmod +x /home/student/gimp.desktop

cp /tmp/librecad.desktop /home/student/librecad.desktop
chown student:student /home/student/librecad.desktop
chmod +x /home/student/librecad.desktop

cp /tmp/seamonkey.desktop /home/student/seamonkey.desktop
chown student:student /home/student/seamonkey.desktop
chmod +x /home/student/seamonkey.desktop

cp /tmp/Redmine.desktop /home/student/Redmine.desktop
chown student:student /home/student/Redmine.desktop
chmod +x /home/student/Redmine.desktop

cp /tmp/nut.desktop /home/student/nut.desktop
chown student:student /home/student/nut.desktop
chmod +x /home/student/nut.desktop

cp /tmp/core.desktop /home/student/core.desktop
chown student:student /home/student/core.desktop
chmod +x /home/student/core.desktop

cp /tmp/ubuntu-software-center.desktop /home/student/ubuntu-software-center.desktop
chown student:student /home/student/ubuntu-software-center.desktop
chmod +x /home/student/ubuntu-software-center.desktop

cp /tmp/skype.desktop /home/student/skype.desktop
chown student:student /home/student/skype.desktop
chmod +x /home/student/skype.desktop

echo "deb http://ppa.launchpad.net/webupd8team/java/ubuntu xenial main" | tee /etc/apt/sources.list.d/webupd8team-java.list
echo "deb-src http://ppa.launchpad.net/webupd8team/java/ubuntu xenial main" | tee -a /etc/apt/sources.list.d/webupd8team-java.list

mv /tmp/keys.sh /home/student
chmod +x /home/student/keys.sh

#cp /tmp/tsrepo.sh /home/student
#chown student:student /home/student/tsrepo.sh
#chmod +x /home/student/tsrepo.sh

mkdir /home/student/.config/autostart 
chown -R student:student /home/student/.config/
chown -R student:student /home/student/.config/autostart/

chmod +x /home/student/startdaemon.sh

cp /home/student/startdaemon.desktop /home/student/.config/autostart/startdaemon.desktop
chown student:student /home/student/.config/autostart/startdaemon.desktop
chmod +x /home/student/.config/autostart/startdaemon.desktop

cp /home/student/RunME.desktop /home/student/.config/autostart/RunME.desktop 
chown student:student /home/student/.config/autostart/RunME.desktop
chmod +x /home/student/.config/autostart/RunMe.desktop

/bin/cp -f /tmp/freedesktop.org.xml /usr/share/mime/packages/freedesktop.org.xml

touch /root/iek64
pip install PyMsgBox
