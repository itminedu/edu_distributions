#!/bin/sh
/bin/sh -c 'cd /tmp && wget ts.sch.gr/repo/add-repo && sh add-repo ts.sch.gr/repo'
/bin/sh -c 'cd /tmp && wget ts.sch.gr/repo/sch-scripts && sh sch-scripts'
