#!/bin/sh
sudo /etc/init.d/core-daemon start
