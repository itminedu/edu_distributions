#!/bin/sh
mkdir /home/student/EducationSoftware
mkdir /home/student/EducationSoftware/Icons

cp /home/student/assets/Xmind.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/Xmind.desktop"

cp /home/student/assets/xmind.png /home/student/EducationSoftware/Icons/xmind.png

cp /home/student/assets/voki.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/voki.desktop"

cp /home/student/assets/vt.png /home/student/EducationSoftware/Icons/vt.png

cp /home/student/assets/timeglider.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/timeglider.desktop"

cp /home/student/assets/url.png /home/student/EducationSoftware/Icons/url.png

cp /home/student/assets/jigsawplanet.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/jigsawplanet.desktop"

cp /home/student/assets/jp.png /home/student/EducationSoftware/Icons/jp.png

cp /home/student/assets/edubuncee.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/edubuncee.desktop"

cp /home/student/assets/edu.png /home/student/EducationSoftware/Icons/edu.png

cp /home/student/assets/tagul.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/tagul.desktop"

cp /home/student/assets/tagul.png /home/student/EducationSoftware/Icons/tagul.png

cp /home/student/assets/zunal.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/zunal.desktop"

cp /home/student/assets/awwapp.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/awwapp.desktop"

cp /home/student/assets/audacity.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/audacity.desktop"

cp /home/student/assets/firefox.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/firefox.desktop"

cp /home/student/assets/k3b.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/k3b.desktop"

cp /home/student/assets/libreofficecalc.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/libreofficecalc.desktop"

cp /home/student/assets/libreofficeimpress.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/libreofficeimpress.desktop"

cp /home/student/assets/libreofficewriter.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/libreofficewriter.desktop"

cp /home/student/assets/openshot.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/openshot.desktop"

cp /home/student/assets/scratch.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/scratch.desktop"

cp /home/student/assets/vlc.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/vlc.desktop"

cp /home/student/assets/Home.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/Home.desktop"

cp /home/student/assets/trash.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/trash.desktop"

uxterm -e "wget -O /home/student/EducationSoftware/xmind-8-linux.zip http://ostdev.minedu.gov.gr/~pgeorg/customDistros/ElementaryEdition/xmind-8-linux.zip ; unzip -o /home/student/EducationSoftware/xmind-8-linux.zip -d /home/student/EducationSoftware/Xmind ; sudo /home/student/EducationSoftware/Xmind/setup.sh ; sudo apt-get update ; sudo apt-get -y --force-yes install oracle-java8-installer ; sudo /home/student/assets/tsrepo.sh ; sudo apt-get -y --force-yes install wine-el ; sudo apt-get -y --force-yes install dimotiko ; sudo apt-get -y --force-yes install dimotiko-extra ; rm /home/student/.kde/Autostart/runme.sh"



