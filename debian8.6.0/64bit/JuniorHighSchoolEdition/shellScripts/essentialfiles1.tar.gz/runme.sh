#!/bin/sh

mkdir /home/student/EducationSoftware
mkdir /home/student/EducationSoftware/Icons
#mkdir /home/student/InitialFiles

cp /home/student/InitialFiles/lightbot-icon-152jr.png /home/student/EducationSoftware/Icons/lightbot-icon-152jr.png
cp /home/student/InitialFiles/xmind.png /home/student/EducationSoftware/Icons/xmind.png
cp /home/student/InitialFiles/asymptopia.png /home/student/EducationSoftware/Icons/asymptopia.png
cp /home/student/InitialFiles/url.png /home/student/EducationSoftware/Icons/url.png

cp /home/student/InitialFiles/aesopos.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/golab.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/timeline.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/timeglider.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/zunal.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/phet.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/asymptopia.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/Xmind.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/libreofficewriter.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/libreofficecalc.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/vlc.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/filezilla.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/firefox.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/audacity.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/openshot.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/k3b.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/lightbot.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/Home.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/trash.desktop "/home/student/Επιφάνεια εργασίας"

chmod +x "/home/student/Επιφάνεια εργασίας/aesopos.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/golab.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/timeline.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/timeglider.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/zunal.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/phet.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/asymptopia.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/Xmind.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/libreofficewriter.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/libreofficecalc.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/vlc.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/filezilla.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/firefox.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/audacity.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/openshot.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/k3b.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/lightbot.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/Home.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/trash.desktop"

uxterm -e "wget -O /home/student/EducationSoftware/xmind-8-linux.zip http://ostdev.minedu.gov.gr/~kotsimp/customDistros/JuniorHighSchool/xmind-8-linux.zip ; unzip -o /home/student/EducationSoftware/xmind-8-linux.zip -d /home/student/EducationSoftware/Xmind ; sudo /home/student/EducationSoftware/Xmind/setup.sh ; sudo apt-get update ; sudo apt-get -y --force-yes install oracle-java8-installer ; sudo /home/student/InitialFiles/tsrepo.sh ; sudo apt-get -y --force-yes install wine-el ; sudo apt-get -y --force-yes install palapeli ; sudo apt-get -y --force-yes install kollision ; sudo apt-get -y --force-yes install kapman ; sudo dpkg --add-architecture i386 ; sudo apt-get update ; sudo apt-get -y --force-yes install wine32 ; rm /home/student/.kde/Autostart/runme.sh"
uxterm -e "wget -O /home/student/EducationSoftware/AsymptopiaXW-3.2.zip http://ostdev.minedu.gov.gr/~kotsimp/customDistros/JuniorHighSchool/AsymptopiaXW-3.2.zip ; unzip -o /home/student/EducationSoftware/AsymptopiaXW-3.2.zip -d /home/student/EducationSoftware/AsymptopiaXW"
uxterm -e "sudo apt-get -y --force-yes install inkscape ; sudo apt-get -y --force-yes install gym-microworlds-c ; sudo apt-get -y --force-yes install pidgin  ; sudo apt-get -y --force-yes install object-karel ; sudo apt-get -y --force-yes install gym-chelonokosmoi ; sudo apt-get -y --force-yes install mortran ; sudo apt-get -y --force-yes install starlogotng ; sudo apt-get -y --force-yes install ekiga ; sudo apt-get -y --force-yes install gym-ksenios ; sudo apt-get -y --force-yes install karel ; sudo apt-get -y --force-yes install glossa ; sudo apt-get -y --force-yes install starlogo"
uxterm -e "sudo apt-get -y --force-yes install gymnasio ; sudo apt-get -y --force-yes install gym-mykinaikos-politismos gym-taxinomoume gym-metanastes"


