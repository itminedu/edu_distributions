#!/bin/sh

mkdir /home/student/EducationSoftware
mkdir /home/student/EducationSoftware/Icons
#mkdir /home/student/InitialFiles

cp /home/student/InitialFiles/ktuberling.png /home/student/EducationSoftware/Icons/ktuberling.png
cp /home/student/InitialFiles/lightbot-icon-152jr.png /home/student/EducationSoftware/Icons/lightbot-icon-152jr.png
cp /home/student/InitialFiles/fountoulis.jpg /home/student/EducationSoftware/Icons/fountoulis.jpg
cp /home/student/InitialFiles/kourdista.jpg /home/student/EducationSoftware/Icons/kourdista.jpg

cp /home/student/InitialFiles/Antonakis.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/gcompris.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/tuxpaint.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/tuxtype.desktop "/home/student/Επιφάνεια εργασίας"
#cp /home/student/InitialFiles/tuxguitar.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/libreofficewriter.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/libreofficecalc.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/vlc.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/filezilla.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/firefox.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/audacity.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/openshot.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/pysiogame.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/childsplay.desktop "/home/student/Επιφάνεια εργασίας"
#cp /home/student/InitialFiles/tuxfootball.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/extremetuxracer.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/blinken.desktop "/home/student/Επιφάνεια εργασίας"
#cp /home/student/InitialFiles/gimp.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/k3b.desktop "/home/student/Επιφάνεια εργασίας"
#cp /home/student/InitialFiles/kapman.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/ktuberling.desktop "/home/student/Επιφάνεια εργασίας"
#cp /home/student/InitialFiles/kblocks.desktop "/home/student/Επιφάνεια εργασίας"
#cp /home/student/InitialFiles/kollision.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/lightbot.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/mathaino_ti_glossa_mou.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/kourdista.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/Home.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/InitialFiles/trash.desktop "/home/student/Επιφάνεια εργασίας"

chmod +x "/home/student/Επιφάνεια εργασίας/Antonakis.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/gcompris.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/tuxpaint.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/tuxtype.desktop"
#chmod +x "/home/student/Επιφάνεια εργασίας/tuxguitar.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/libreofficewriter.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/libreofficecalc.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/vlc.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/filezilla.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/firefox.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/audacity.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/openshot.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/pysiogame.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/childsplay.desktop"
#chmod +x "/home/student/Επιφάνεια εργασίας/tuxfootball.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/extremetuxracer.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/blinken.desktop"
#chmod +x "/home/student/Επιφάνεια εργασίας/gimp.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/k3b.desktop"
#chmod +x "/home/student/Επιφάνεια εργασίας/kapman.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/ktuberling.desktop"
#chmod +x "/home/student/Επιφάνεια εργασίας/kblocks.desktop"
#chmod +x "/home/student/Επιφάνεια εργασίας/kollision.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/lightbot.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/mathaino_ti_glossa_mou.desktop"
chmod +x "/home/student/kourdista.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/Home.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/trash.desktop"

uxterm -e "sudo apt-get update ; sudo /home/student/InitialFiles/tsrepo.sh ; sudo apt-get -y --force-yes install wine-el ; sudo apt-get -y --force-yes install ktuberling ; sudo apt-get -y --force-yes install kollision ; sudo apt-get -y --force-yes install kapman ; rm /home/student/.kde/Autostart/runme.sh"
#uxterm -e "mv /home/student/.kde/Autostart/runme.sh /home/student/runme.sh ; mv /home/student/*.desktop /home/student/InitialFiles ; mv /home/student/*.sh /home/student/InitialFiles ; mv /home/student/*.png /home/student/InitialFiles ; mv /home/student/*.jpg /home/student/InitialFiles"
uxterm -e "wget -O /home/student/EducationSoftware/kourdista.tar.gz http://ostdev.minedu.gov.gr/~kotsimp/customDistros/PreschoolEdition/kourdista.tar.gz ; tar -xzvf /home/student/EducationSoftware/kourdista.tar.gz -C /home/student/EducationSoftware ; wget -O /home/student/EducationSoftware/mathaino_ti_glossa_mou.tar.gz http://ostdev.minedu.gov.gr/~kotsimp/customDistros/PreschoolEdition/mathaino_ti_glossa_mou.tar.gz ; tar -xzvf /home/student/EducationSoftware/mathaino_ti_glossa_mou.tar.gz -C /home/student/EducationSoftware ; sudo dpkg --add-architecture i386 ; sudo apt-get update ; sudo apt-get -y --force-yes install wine32"
uxterm -e "wget -O /home/student/EducationSoftware/OiAporiesTouAntonaki.tar.gz http://ostdev.minedu.gov.gr/~kotsimp/customDistros/PreschoolEdition/OiAporiesTouAntonaki.tar.gz ; tar -xzvf /home/student/EducationSoftware/OiAporiesTouAntonaki.tar.gz -C /home/student/EducationSoftware"

