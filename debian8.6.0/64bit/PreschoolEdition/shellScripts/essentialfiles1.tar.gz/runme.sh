#!/bin/sh

mkdir /home/student/EducationSoftware
mkdir /home/student/Icons
mkdir /home/student/InitialFiles

cp /home/student/ktuberling.png /home/student/Icons/ktuberling.png
cp /home/student/lightbot-icon-152jr.png /home/student/Icons/lightbot-icon-152jr.png
cp /home/student/fountoulis.jpg /home/student/Icons/fountoulis.jpg
cp /home/student/kourdista.jpg /home/student/Icons/kourdista.jpg

cp /home/student/gcompris.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/tuxpaint.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/tuxtype.desktop "/home/student/Επιφάνεια εργασίας"
#cp /home/student/tuxguitar.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/libreofficewriter.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/libreofficecalc.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/vlc.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/filezilla.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/firefox.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/audacity.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/openshot.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/pysiogame.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/childsplay.desktop "/home/student/Επιφάνεια εργασίας"
#cp /home/student/tuxfootball.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/extremetuxracer.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/blinken.desktop "/home/student/Επιφάνεια εργασίας"
#cp /home/student/gimp.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/k3b.desktop "/home/student/Επιφάνεια εργασίας"
#cp /home/student/kapman.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/ktuberling.desktop "/home/student/Επιφάνεια εργασίας"
#cp /home/student/kblocks.desktop "/home/student/Επιφάνεια εργασίας"
#cp /home/student/kollision.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/lightbot.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/mathaino_ti_glossa_mou.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/kourdista.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/Home.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/trash.desktop "/home/student/Επιφάνεια εργασίας"
#cp /home/student/*.desktop "/home/student/Επιφάνεια εργασίας"




chmod +x "/home/student/Επιφάνεια εργασίας/gcompris.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/tuxpaint.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/tuxtype.desktop"
#chmod +x "/home/student/Επιφάνεια εργασίας/tuxguitar.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/libreofficewriter.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/libreofficecalc.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/vlc.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/filezilla.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/firefox.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/audacity.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/openshot.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/pysiogame.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/childsplay.desktop"
#chmod +x "/home/student/Επιφάνεια εργασίας/tuxfootball.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/extremetuxracer.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/blinken.desktop"
#chmod +x "/home/student/Επιφάνεια εργασίας/gimp.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/k3b.desktop"
#chmod +x "/home/student/Επιφάνεια εργασίας/kapman.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/ktuberling.desktop"
#chmod +x "/home/student/Επιφάνεια εργασίας/kblocks.desktop"
#chmod +x "/home/student/Επιφάνεια εργασίας/kollision.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/lightbot.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/mathaino_ti_glossa_mou.desktop"
chmod +x "/home/student/kourdista.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/Home.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/trash.desktop"

uxterm -e "sudo apt-get update ; sudo /home/student/tsrepo.sh ; sudo apt-get -y --force-yes install wine-el ; sudo apt-get -y --force-yes install ktuberling ; sudo apt-get -y --force-yes install kollision ; sudo apt-get -y --force-yes install kapman ; mv /home/student/.kde/Autostart/runme.sh /home/student/runme.sh"
uxterm -e "mv /home/student/*.desktop /home/student/InitialFiles ; mv /home/student/*.sh /home/student/InitialFiles ; mv /home/student/*.png /home/student/InitialFiles ; mv /home/student/*.jpg /home/student/InitialFiles"
#uxterm -e "rm /home/student/*.desktop ; rm /home/student/*.sh ; rm /home/student/*.png"
#uxterm -e "sudo apt-get -y --force-yes install nipiagogeio"
uxterm -e "wget -O /home/student/EducationSoftware/kourdista.tar.gz http://ostdev.minedu.gov.gr/~kotsimp/customDistros/PreschoolEdition/kourdista.tar.gz ; tar -xzvf /home/student/EducationSoftware/kourdista.tar.gz -C /home/student/EducationSoftware ; wget -O /home/student/EducationSoftware/mathaino_ti_glossa_mou.tar.gz http://ostdev.minedu.gov.gr/~kotsimp/customDistros/PreschoolEdition/mathaino_ti_glossa_mou.tar.gz ; tar -xzvf /home/student/EducationSoftware/mathaino_ti_glossa_mou.tar.gz -C /home/student/EducationSoftware ; sudo dpkg --add-architecture i386 ; sudo apt-get update ; sudo apt-get -y --force-yes install wine32"

