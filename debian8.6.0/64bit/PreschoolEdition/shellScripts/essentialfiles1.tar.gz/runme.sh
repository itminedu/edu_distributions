#!/bin/sh

mkdir /home/student/EducationSoftware
mkdir /home/student/Icons

cp /home/student/ktuberling.png /home/student/Icons/ktuberling.png

cp /home/student/gcompris.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/tuxpaint.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/tuxtype.desktop "/home/student/Επιφάνεια εργασίας"
#cp /home/student/tuxguitar.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/libreofficewriter.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/libreofficecalc.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/vlc.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/filezilla.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/firefox.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/audacity.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/openshot.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/pysiogame.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/childsplay.desktop "/home/student/Επιφάνεια εργασίας"
#cp /home/student/tuxfootball.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/extremetuxracer.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/blinken.desktop "/home/student/Επιφάνεια εργασίας"
#cp /home/student/gimp.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/k3b.desktop "/home/student/Επιφάνεια εργασίας"
#cp /home/student/kapman.desktop "/home/student/Επιφάνεια εργασίας"
cp /home/student/ktuberling.desktop "/home/student/Επιφάνεια εργασίας"
#cp /home/student/kblocks.desktop "/home/student/Επιφάνεια εργασίας"
#cp /home/student/kollision.desktop "/home/student/Επιφάνεια εργασίας"
#cp /home/student/*.desktop "/home/student/Επιφάνεια εργασίας"


chmod +x "/home/student/Επιφάνεια εργασίας/gcompris.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/tuxpaint.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/tuxtype.desktop"
#chmod +x "/home/student/Επιφάνεια εργασίας/tuxguitar.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/libreofficewriter.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/libreofficecalc.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/vlc.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/filezilla.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/firefox.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/audacity.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/openshot.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/pysiogame.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/childsplay.desktop"
#chmod +x "/home/student/Επιφάνεια εργασίας/tuxfootball.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/extremetuxracer.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/blinken.desktop"
#chmod +x "/home/student/Επιφάνεια εργασίας/gimp.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/k3b.desktop"
#chmod +x "/home/student/Επιφάνεια εργασίας/kapman.desktop"
chmod +x "/home/student/Επιφάνεια εργασίας/ktuberling.desktop"
#chmod +x "/home/student/Επιφάνεια εργασίας/kblocks.desktop"
#chmod +x "/home/student/Επιφάνεια εργασίας/kollision.desktop"

uxterm -e "sudo apt-get update ; sudo /home/student/tsrepo.sh ; sudo apt-get -y --force-yes install wine-el ; sudo apt-get -y --force-yes install ktuberling ; sudo apt-get -y --force-yes install kollision ; sudo apt-get -y --force-yes install kapman ; rm /home/student/*.desktop ; rm /home/student/*.sh ; rm /home/student/*.png"
#uxterm -e "sudo apt-get -y --force-yes install nipiagogeio"

uxterm -e "wget -O /home/student/EducationSoftware/kourdista.tar.gz http://ostdev.minedu.gov.gr/~kotsimp/customDistros/PreschoolEdition/kourdista.tar.gz ; tar -xvf /home/student/EducationSoftware/kourdista.tar.gz -C /home/student/EducationSoftware ; wget -O /home/student/EducationSoftware/mathaino_glossa.tar.gz http://ostdev.minedu.gov.gr/~kotsimp/customDistros/PreschoolEdition/mathaino_glossa.tar.gz ; tar -xvf /home/student/EducationSoftware/mathaino_glossa.tar.gz -C /home/student/EducationSoftware"

