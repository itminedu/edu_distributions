#!/bin/sh

cp /tmp/ktuberling.png /home/student
cp /tmp/gcompris.desktop /home/student/gcompris.desktop ; \
cp /tmp/tuxpaint.desktop /home/student/tuxpaint.desktop ; \
cp /tmp/tuxtype.desktop /home/student/tuxtype.desktop ; \
#cp /tmp/tuxguitar.desktop /home/student/tuxguitar.desktop ; \
cp /tmp/libreofficewriter.desktop /home/student/libreofficewriter.desktop ; \
cp /tmp/libreofficecalc.desktop /home/student/libreofficecalc.desktop ; \
cp /tmp/vlc.desktop /home/student/vlc.desktop ; \
cp /tmp/filezilla.desktop /home/student/filezilla.desktop ; \
cp /tmp/firefox.desktop /home/student/firefox.desktop ; \
cp /tmp/audacity.desktop /home/student/audacity.desktop ; \
cp /tmp/openshot.desktop /home/student/openshot.desktop ; \
cp /tmp/pysiogame.desktop /home/student/pysiogame.desktop ; \
cp /tmp/childsplay.desktop /home/student/childsplay.desktop ; \  
#cp /tmp/tuxfootball.desktop /home/student/tuxfootball.desktop ; \
cp /tmp/extremetuxracer.desktop /home/student/extremetuxracer.desktop ; \
cp /tmp/blinken.desktop /home/student/blinken.desktop ; \
#cp /tmp/blinken.desktop /home/student/gimp.desktop ; \
cp /tmp/k3b.desktop /home/student/k3b.desktop ; \
#cp /tmp/kapman.desktop /home/student/kapman.desktop ; \
cp /tmp/ktuberling.desktop /home/student/ktuberling.desktop ; \
#cp /tmp/kblocks.desktop /home/student/kblocks.desktop ; \
#cp /tmp/kollision.desktop /home/student/kollision.desktop ; \
  
chown student:student /home/student/ktuberling.png
chown student:student /home/student/gcompris.desktop ; \
chown student:student /home/student/tuxpaint.desktop ; \
chown student:student /home/student/tuxtype.desktop ; \
#chown student:student /home/student/tuxguitar.desktop ; \
chown student:student /home/student/libreofficewriter.desktop ; \
chown student:student /home/student/libreofficecalc.desktop ; \
chown student:student /home/student/vlc.desktop ; \
chown student:student /home/student/filezilla.desktop ; \
chown student:student /home/student/firefox.desktop ; \
chown student:student /home/student/audacity.desktop ; \
chown student:student /home/student/openshot.desktop ; \
chown student:student /home/student/pysiogame.desktop ; \
chown student:student /home/student/childsplay.desktop ; \
#chown student:student /home/student/tuxfootball.desktop ; \
chown student:student /home/student/extremetuxracer.desktop ; \
chown student:student /home/student/blinken.desktop ; \
#chown student:student /home/student/gimp.desktop ; \
chown student:student /home/student/k3b.desktop ; \
#chown student:student /home/student/kapman.desktop ; \
chown student:student /home/student/ktuberling.desktop ; \
#chown student:student /home/student/kblocks.desktop ; \
#chown student:student /home/student/kollision.desktop ; \
  
chmod +x /home/student/*.desktop ; \
  
echo "deb http://ppa.launchpad.net/webupd8team/java/ubuntu xenial main" | tee /etc/apt/sources.list.d/webupd8team-java.list
echo "deb-src http://ppa.launchpad.net/webupd8team/java/ubuntu xenial main" | tee -a /etc/apt/sources.list.d/webupd8team-java.list
cp /tmp/tsrepo.sh /home/student
chown student:student /home/student/tsrepo.sh
chmod +x /home/student/tsrepo.sh
pip install PyMsgBox
