#!/bin/sh
mkdir /home/student/EducationSoftware
mkdir /home/student/images

cp /home/student/audacity.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/audacity.desktop"

#cp /home/student/k3b.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/k3b.desktop"
#cp /home/student/libreofficecalc.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/libreofficecalc.desktop"
#cp /home/student/libreofficeimpress.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/libreofficeimpress.desktop"
#cp /home/student/libreofficewriter.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/libreofficewriter.desktop"

cp /home/student/openshot.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/openshot.desktop"

cp /home/student/scratch.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/scratch.desktop"

#cp /home/student/vlc.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/vlc.desktop"

cp /home/student/lmms.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/lmms.desktop"

#cp /home/student/audacious.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/audacious.desktop"
#cp /home/student/linphone.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/linphone.desktop"

cp /home/student/blender.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/blender.desktop"

cp /home/student/geany.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/geany.desktop"

cp /home/student/greenfoot.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/greenfoot.desktop"

cp /home/student/geogebra.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/geogebra.desktop"

cp /home/student/netbeans.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/netbeans.desktop"

cp /home/student/dia.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/dia.desktop"

#cp /home/student/dolibarr.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/dolibarr.desktop"

cp /home/student/gimp.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/gimp.desktop"

cp /home/student/librecad.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/librecad.desktop"

cp /home/student/gravit.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/gravit.desktop"

cp /home/student/xplanets.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/xplanets.desktop"

cp /home/student/physicslab.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/physicslab.desktop"

cp /home/student/falstad.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/falstad.desktop"

cp /home/student/eol.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/eol.desktop"

cp /home/student/biodigital.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/biodigital.desktop"

cp /home/student/hybrid.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/hybrid.desktop"

cp /home/student/innerbody.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/innerbody.desktop"

cp /home/student/zygotebody.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/zygotebody.desktop"

cp /home/student/Sublime.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/Sublime.desktop"

uxterm -e "wget http://ostdev.minedu.gov.gr/~afpapag/CustomDistros/EpalEdition/sublime_text_3_build_x32.tar.bz2 ; tar xjvf /home/student/sublime_text_3_build_x32.tar.bz2;  mv /home/student/sublime_text_3_build_x32.tar.bz2 /home/student/EducationSoftware/sublime_text_3_build_x32.tar.bz2; mv /home/student/sublime_text_3 /home/student/EducationSoftware; wget http://ostdev.minedu.gov.gr/~pgeorg/customDistros/developerEdition/netbeans-8.1-linux.sh /home/student; chmod +x /home/student/netbeans-8.1-linux.sh; sudo apt-get update; sudo apt-get -y --force-yes install oracle-java8-installer; sudo /home/student/tsrepo.sh; sudo apt-get -y --force-yes install wine-el; sudo apt-get -y install eclipse; sudo apt-get -y install eclipse-cdt; sudo apt-get -y install scribus-ng; sudo apt-get -y install greenfoot; mv /home/student/netbeans-8.1-linux.sh /home/student/EducationSoftware; mv /home/student/*.desktop /home/student/EducationSoftware; mv /home/student/*.sh /home/student/EducationSoftware; mv /home/student/*.png /home/student/images"






