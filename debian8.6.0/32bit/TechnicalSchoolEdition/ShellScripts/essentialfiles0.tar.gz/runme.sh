#!/bin/sh
mkdir /home/student/EducationSoftware
mkdir /home/student/EducationSoftware/FlashPlayer
mkdir /home/student/images
cd /home/student

cp /home/student/Synfig.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/Synfig.desktop"

#cp /home/student/Wings.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/Wings.desktop"

cp /home/student/audacity.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/audacity.desktop"

#cp /home/student/k3b.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/k3b.desktop"
#cp /home/student/libreofficecalc.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/libreofficecalc.desktop"
#cp /home/student/libreofficeimpress.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/libreofficeimpress.desktop"
#cp /home/student/libreofficewriter.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/libreofficewriter.desktop"

cp /home/student/openshot.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/openshot.desktop"

cp /home/student/scratch.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/scratch.desktop"

#cp /home/student/vlc.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/vlc.desktop"

cp /home/student/lmms.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/lmms.desktop"

#cp /home/student/audacious.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/audacious.desktop"
#cp /home/student/linphone.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/linphone.desktop"

#cp /home/student/blender.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/blender.desktop"

cp /home/student/geany.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/geany.desktop"

cp /home/student/greenfoot.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/greenfoot.desktop"

cp /home/student/geogebra.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/geogebra.desktop"

cp /home/student/netbeans.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/netbeans.desktop"

#cp /home/student/dia.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/dia.desktop"

#cp /home/student/dolibarr.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/dolibarr.desktop"

cp /home/student/gimp.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/gimp.desktop"

cp /home/student/librecad.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/librecad.desktop"

cp /home/student/gravit.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/gravit.desktop"

cp /home/student/xplanets.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/xplanets.desktop"

cp /home/student/physicslab.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/physicslab.desktop"

cp /home/student/falstad.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/falstad.desktop"

cp /home/student/eol.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/eol.desktop"

cp /home/student/biodigital.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/biodigital.desktop"

cp /home/student/hybrid.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/hybrid.desktop"

cp /home/student/innerbody.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/innerbody.desktop"

cp /home/student/zygotebody.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/zygotebody.desktop"

cp /home/student/Sublime.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/Sublime.desktop"

cp /home/student/seamonkey.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/seamonkey.desktop"

cp /home/student/CPUSim.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/CPUSim.desktop"

cp /home/student/EDUmips.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/EDUmips.desktop"

cp /home/student/PI.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/PI.desktop"

cp /home/student/PyCAM.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/PyCAM.desktop"

cp /home/student/core.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/core.desktop"

uxterm -e "wget -O /home/student/EducationSoftware/FlashPlayer/flash_player_npapi_linux.i386.tar.gz http://ostdev.minedu.gov.gr/~sofiakom/customDistros/HighSchoolEdition/flash_player_npapi_linux.i386.tar.gz ; 
tar xvf /home/student/EducationSoftware/FlashPlayer/flash_player_npapi_linux.i386.tar.gz -C  /home/student/EducationSoftware/FlashPlayer ; 

sudo cp /home/student/EducationSoftware/FlashPlayer/libflashplayer.so /usr/lib/mozilla/plugins ; 
sudo cp -r /home/student/EducationSoftware/FlashPlayer/usr/* /usr ;

wget http://ostdev.minedu.gov.gr/~afpapag/CustomDistros/EpalEdition/sublime_text_3_build_x32.tar.bz2 ; tar xjvf /home/student/sublime_text_3_build_x32.tar.bz2;  mv /home/student/sublime_text_3_build_x32.tar.bz2 /home/student/EducationSoftware/sublime_text_3_build_x32.tar.bz2; mv /home/student/sublime_text_3 /home/student/EducationSoftware; 

wget http://ostdev.minedu.gov.gr/~pgeorg/customDistros/developerEdition/netbeans-8.1-linux.sh /home/student; chmod +x /home/student/netbeans-8.1-linux.sh; 

wget http://ftp.mozilla.org/pub/mozilla.org/seamonkey/releases/2.33/linux-i686/en-GB/seamonkey-2.33.tar.bz2 /home/student/seamonkey-2.33.tar.bz2; tar -xjvf /home/student/seamonkey-2.33.tar.bz2;

wget http://downloads.pf.itd.nrl.navy.mil/ospf-manet/quagga-0.99.21mr2.2/quagga-mr_0.99.21mr2.2_i386.deb /home/student/quagga-mr_0.99.21mr2.2_i386.deb;
wget http://downloads.pf.itd.nrl.navy.mil/core/packages/4.8/core-daemon_4.8-0ubuntu1_precise_i386.deb /home/student/core-daemon_4.8-0ubuntu1_precise_i386.deb; wget http://downloads.pf.itd.nrl.navy.mil/core/packages/4.8/core-gui_4.8-0ubuntu1_precise_all.deb /home/student/core-gui_4.8-0ubuntu1_precise_all.deb; 

sudo apt-get dist-upgrade; sudo apt-get -y --force-yes install bash bridge-utils ebtables iproute libev-dev python tcl8.5 tk8.5 libtk-img; 
sudo dpkg -i quagga-mr_0.99.21mr2.2_i386.deb; sudo apt-get -y --force-yes install quagga; sudo dpkg -i core-daemon_4.8-0ubuntu1_precise_i386.deb; sudo dpkg -i core-gui_4.8-0ubuntu1_precise_all.deb; sudo /etc/init.d/core-daemon start; 

wget https://launchpad.net/~kritalime/+archive/ubuntu/ppa;

wget https://sourceforge.net/projects/synfig/files/snapshots/1.3.1-20170202/linux/synfigstudio-1.3.1-20170202-32bit.appimage

wget http://ostdev.minedu.gov.gr/~afpapag/CustomDistros/EpalEdition/bluegriffon_2.3.1-1ubuntu1_i386.deb;
sudo dpkg -i bluegriffon_2.3.1-1ubuntu1_i386.deb;

sudo apt-get update; 
sudo apt-get -y --force-yes install oracle-java8-installer; 
wget -O /home/student/EducationSoftware/Greenfoot-linux-304.deb http://ostdev.minedu.gov.gr/~sofiakom/customDistros/HighSchoolEdition/Greenfoot-linux-304.deb ; sudo dpkg -i /home/student/EducationSoftware/Greenfoot-linux-304.deb ;

wget intro.bio.umb.edu/PI/PI.tar.gz; tar xvf PI.tar.gz;


sudo apt-get -f install; 
sudo apt-get -y --force-yes install dolibarr;

sudo apt-get -y --force-yes install eclipse; sudo apt-get -y --force-yes install eclipse-cdt; 

sudo apt-get -y --force-yes install scribus-ng;

sudo apt-get autoremove; 
sudo apt-get -y --force-yes install pspp;    

sudo apt-get -y --force-yes install bluefish;

sudo apt-get -y --force-yes install valentina;

sudo apt-get -y --force-yes install p7zip-full;

sudo apt-get -y --force-yes install krita;

sudo apt-get -y --force-yes install testdisk;

sudo apt-get -y --force-yes install wireshark;

sudo /home/student/tsrepo.sh;
sudo apt-get -y --force-yes install wine-el; sudo apt-get -y --force-yes install karel; 
sudo apt-get -y --force-yes install wine32; sudo apt-get -y --force-yes install glossa;

sudo apt-get -y --force-yes install lyk-taxidi-se-ena-diktyo; 

sudo apt-get -y --force-yes install ekiga;
sudo apt-get -y --force-yes install tee-i-zografiki-apo-ton-19o-ston-20o-aiona; 

sudo apt-get -y --force-yes install kazam;
sudo apt-get -y --force-yes install kdenlive;
sudo apt-get -y --force-yes install gpsim;


chmod a+x synfigstudio-1.3.1-20170202-32bit.appimage;

sudo apt-get -y --force-yes install python-gtkglext1;
sudo apt-get -y --force-yes install python-opengl;
sudo apt-get -y --force-yes install python-gtk2;
wget https://github.com/SebKuzminsky/pycam/releases/download/v0.6.1/pycam-0.6.1.tar.gz; 
tar xvf pycam-0.6.1.tar.gz;

wget download.tuxfamily.org/morevna/morevnapackage/binaries/pencil/pencil2d_0.5.4-20130728.1_i386.deb;
sudo dpkg -i pencil2d_0.5.4-20130728.1_i386.deb;

wget  security.debian.org/debian-security/pool/updates/main/libg/libgcrypt11/libgcrypt11_1.5.0-5+deb7u5_i386.deb;
sudo dpkg -i libgcrypt11_1.5.0-5+deb7u5_i386.deb;
wget https://github.com/adobe/brackets/releases/download/release-1.9-prerelease/Brackets.Release.release-1.9-prerelease.32-bit.deb;
sudo dpkg -i Brackets.Release.release-1.9-prerelease.32-bit.deb;

wget https://launchpad.net/~qucs/+archive/ubuntu/qucs/+files/qucs_0.0.18-2_i386.deb;
sudo dpkg -i qucs_0.0.18-2_i386.deb;

wget http://ostdev.minedu.gov.gr/~afpapag/CustomDistros/EpalEdition/brlcad_7.26.0-0.2_i386.deb;
sudo dpkg -i brlcad_7.26.0-0.2_i386.deb;

wget https://github.com/lupino3/edumips64/releases/download/v1.2.2/edumips64-1.2.2.jar;

wget www.cs.colby.edu/djskrien/CPUSim/CPUSim4.0.9.zip; unzip CPUSim4.0.9.zip; 

wget www.bluej.org/download/files/BlueJ-linux-400.deb; sudo dpkg -i BlueJ-linux-400.deb;



mv /home/student/netbeans-8.1-linux.sh /home/student/EducationSoftware; mv /home/student/*.desktop /home/student/EducationSoftware; mv /home/student/*.sh /home/student/EducationSoftware"

uxterm -e "rm /home/student/.kde/Autostart/runme.sh"

#wget http://sourceforge.net/projects/wings/files/wings/1.5.3/wings-1.5.3-linux.bzip2.run;
#chmod +x wings-1.5.3-linux.bzip2.run; ./wings-1.5.3-linux.bzip2.run; 





