#!/bin/sh
mkdir /home/student/EducationSoftware
mkdir /home/student/EducationSoftware/Icons
mkdir /home/student/EducationSoftware/FlashPlayer
mkdir /home/student/EducationSoftware/MolecularWorkbench

cp /home/student/assets/Xmind.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/Xmind.desktop"

cp /home/student/assets/pi.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/pi.desktop"

cp /home/student/assets/genex.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/genex.desktop"

cp /home/student/assets/mw.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/mw.desktop"

cp /home/student/assets/xmind.png /home/student/EducationSoftware/Icons/xmind.png
cp /home/student/assets/pi.png /home/student/EducationSoftware/Icons/pi.png
cp /home/student/assets/genex.png /home/student/EducationSoftware/Icons/genex.png
cp /home/student/assets/mw.png /home/student/EducationSoftware/Icons/mw.png
cp /home/student/assets/ime.png /home/student/EducationSoftware/Icons/ime.png

cp /home/student/assets/timeglider.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/timeglider.desktop"


cp /home/student/assets/phet.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/phet.desktop"

cp /home/student/assets/url.png /home/student/EducationSoftware/Icons/url.png


cp /home/student/assets/audacity.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/audacity.desktop"

cp /home/student/assets/firefox.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/firefox.desktop"

cp /home/student/assets/k3b.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/k3b.desktop"

cp /home/student/assets/libreofficecalc.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/libreofficecalc.desktop"

cp /home/student/assets/libreofficeimpress.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/libreofficeimpress.desktop"

cp /home/student/assets/libreofficewriter.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/libreofficewriter.desktop"

cp /home/student/assets/openshot.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/openshot.desktop"

cp /home/student/assets/librecad.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/librecad.desktop"

cp /home/student/assets/inkscape.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/inkscape.desktop"

cp /home/student/assets/vlc.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/vlc.desktop"

cp /home/student/assets/Home.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/Home.desktop"

cp /home/student/assets/trash.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/trash.desktop"

cp /home/student/assets/ime.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/ime.desktop"

uxterm -e "wget -O /home/student/EducationSoftware/FlashPlayer/flash_player_npapi_linux.i386.tar.gz http://ostdev.minedu.gov.gr/~sofiakom/customDistros/HighSchoolEdition/flash_player_npapi_linux.i386.tar.gz ; tar xvf /home/student/EducationSoftware/FlashPlayer/flash_player_npapi_linux.i386.tar.gz -C  /home/student/EducationSoftware/FlashPlayer ; sudo cp /home/student/EducationSoftware/FlashPlayer/libflashplayer.so /usr/lib/mozilla/plugins ; sudo cp -r /home/student/EducationSoftware/FlashPlayer/usr/* /usr ; wget -O /home/student/EducationSoftware/MolecularWorkbench/mw.jar http://ostdev.minedu.gov.gr/~sofiakom/customDistros/HighSchoolEdition/mw.jar ; wget -O /home/student/EducationSoftware/xmind-8-linux.zip http://ostdev.minedu.gov.gr/~pgeorg/customDistros/ElementaryEdition/xmind-8-linux.zip ; unzip -o /home/student/EducationSoftware/xmind-8-linux.zip -d /home/student/EducationSoftware/Xmind ; sudo /home/student/EducationSoftware/Xmind/setup.sh ;  wget -O /home/student/EducationSoftware/PI.tar.gz http://ostdev.minedu.gov.gr/~sofiakom/customDistros/HighSchoolEdition/PI.tar.gz ; tar xvf /home/student/EducationSoftware/PI.tar.gz -C  /home/student/EducationSoftware ; wget -O /home/student/EducationSoftware/GX.tar.gz http://ostdev.minedu.gov.gr/~sofiakom/customDistros/HighSchoolEdition/GX.tar.gz ; tar xvf /home/student/EducationSoftware/GX.tar.gz -C  /home/student/EducationSoftware ; sudo apt-get update ; sudo apt-get -y --force-yes install oracle-java8-installer ; wget -O /home/student/EducationSoftware/Greenfoot-linux-304.deb http://ostdev.minedu.gov.gr/~sofiakom/customDistros/HighSchoolEdition/Greenfoot-linux-304.deb ; sudo dpkg -i /home/student/EducationSoftware/Greenfoot-linux-304.deb ; wget -O /home/student/EducationSoftware/appinventor2-setup_2.3_all.deb http://ostdev.minedu.gov.gr/~sofiakom/customDistros/HighSchoolEdition/appinventor2-setup_2.3_all.deb ; sudo dpkg -i /home/student/EducationSoftware/appinventor2-setup_2.3_all.deb ; sudo /home/student/assets/tsrepo.sh ; sudo apt-get -y --force-yes install lykeio ; sudo apt-get -y --force-yes install lyk-dimosios-kai-idiotikos-vios-stin-archaia-ellada-dimosios-vios ; sudo apt-get -y --force-yes install lyk-dimosios-kai-idiotikos-vios-stin-archaia-ellada-idiotikos-vios;  sudo apt-get -y --force-yes install lyk-geometrikoi-metaschimatismoi ; sudo apt-get -y --force-yes install wine-el ; sudo apt-get -y --force-yes install wine32 ; sudo apt-get install glossa ; sudo apt-get -y --force-yes remove flowprogramming ; sudo apt-get -y --force-yes install lyk-avakio; rm /home/student/.kde/Autostart/runme.sh"
 
