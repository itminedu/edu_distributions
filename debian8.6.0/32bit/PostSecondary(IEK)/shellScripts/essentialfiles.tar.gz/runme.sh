#!/bin/sh
mkdir /home/student/EducationSoftware
mkdir /home/student/photo
mkdir /home/student/EducationSoftware/FlashPlayer
cd /home/student

cp /home/student/nut.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/nut.desktop"

cp /home/student/biodigital.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/biodigital.desktop"

cp /home/student/hybrid.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/hybrid.desktop"

cp /home/student/innerbody.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/innerbody.desktop"

cp /home/student/zygotebody.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/zygotebody.desktop"

#cp /home/student/audacity.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/audacity.desktop"

cp /home/student/firefox.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/firefox.desktop"

#cp /home/student/k3b.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/k3b.desktop"
#cp /home/student/libreofficecalc.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/libreofficecalc.desktop"
#cp /home/student/libreofficeimpress.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/libreofficeimpress.desktop"
#cp /home/student/libreofficewriter.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/libreofficewriter.desktop"

#cp /home/student/openshot.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/openshot.desktop"

cp /home/student/vlc.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/vlc.desktop"

#cp /home/student/lmms.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/lmms.desktop"

#cp /home/student/audacious.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/audacious.desktop"
#cp /home/student/linphone.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/linphone.desktop"

#cp /home/student/blender.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/blender.desktop"

#cp /home/student/geany.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/geany.desktop"

#cp /home/student/greenfoot.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/greenfoot.desktop"

cp /home/student/netbeans.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/netbeans.desktop"

cp /home/student/dia.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/dia.desktop"

cp /home/student/dolibarr.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/dolibarr.desktop"

cp /home/student/gimp.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/gimp.desktop"

cp /home/student/librecad.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/librecad.desktop"

cp /home/student/falstad.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/falstad.desktop"


cp /home/student/kicad.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/kicad.desktop"

cp /home/student/seamonkey.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/seamonkey.desktop"

#cp /home/student/freecad.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/freecad.desktop"

#cp /home/student/Eclipse.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/Eclipse.desktop"

#cp /home/student/eol.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/eol.desktop"

cp /home/student/biodigital.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/biodigital.desktop"

cp /home/student/hybrid.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/hybrid.desktop"

cp /home/student/innerbody.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/innerbody.desktop"

cp /home/student/zygotebody.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/zygotebody.desktop"

cp /home/student/Sublime.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/Sublime.desktop"

cp /home/student/Redmine.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/Redmine.desktop"

#cp /home/student/core.desktop "/home/student/Επιφάνεια εργασίας"
#chmod +x "/home/student/Επιφάνεια εργασίας/core.desktop"

uxterm -e "wget -O /home/student/EducationSoftware/FlashPlayer/flash_player_npapi_linux.i386.tar.gz http://ostdev.minedu.gov.gr/~sofiakom/customDistros/HighSchoolEdition/flash_player_npapi_linux.i386.tar.gz; tar xvf /home/student/EducationSoftware/FlashPlayer/flash_player_npapi_linux.i386.tar.gz -C  /home/student/EducationSoftware/FlashPlayer ; sudo cp /home/student/EducationSoftware/FlashPlayer/libflashplayer.so /usr/lib/mozilla/plugins ; sudo cp -r /home/student/EducationSoftware/FlashPlayer/usr/* /usr ; 

wget http://ostdev.minedu.gov.gr/~afpapag/CustomDistros/EpalEdition/sublime_text_3_build_x32.tar.bz2; tar xjvf /home/student/sublime_text_3_build_x32.tar.bz2; mv /home/student/sublime_text_3 /home/student/EducationSoftware; 

wget http://ostdev.minedu.gov.gr/~pgeorg/customDistros/developerEdition/netbeans-8.1-linux.sh /home/student; chmod +x /home/student/netbeans-8.1-linux.sh; 
mv /home/student/netbeans-8.1-linux.sh /home/student/EducationSoftware; 

wget http://ostdev.minedu.gov.gr/~afpapag/CustomDistros/EpalEdition/aoi.zip /home/student/; 

wget http://ftp.mozilla.org/pub/mozilla.org/seamonkey/releases/2.33/linux-i686/en-GB/seamonkey-2.33.tar.bz2 /home/student/seamonkey-2.33.tar.bz2; tar -xjvf /home/student/seamonkey-2.33.tar.bz2;

wget http://downloads.pf.itd.nrl.navy.mil/core/packages/4.8/core-daemon_4.8-0ubuntu1_precise_i386.deb /home/student/core-daemon_4.8-0ubuntu1_precise_i386.deb; wget http://downloads.pf.itd.nrl.navy.mil/core/packages/4.8/core-gui_4.8-0ubuntu1_precise_all.deb /home/student/core-gui_4.8-0ubuntu1_precise_all.deb;  

sudo apt-get update
sudo apt-get -y --force-yes install oracle-java8-installer; 
sudo apt-get -y --force-yes install eclipse; sudo apt-get -y --force-yes install eclipse-cdt; 
sudo apt-get -y --force-yes install  scribus-ng;
 
sudo apt-get -f install; 

sudo apt-get -y --force-yes install hoteldruid;
sudo apt-get -y --force-yes install dolibarr;
sudo apt-get -y --force-yes install kmymoney;
sudo apt-get -y --force-yes install qgis python-qgis qgis-plugin-grass; 
sudo apt-get purge gnucash; sudo apt-get update; sudo apt-get -y --force-yes install gnucash;

sudo apt-get autoremove; 
sudo apt-get -y --force-yes install pspp;    
sudo apt-get -y --force-yes install r-base; sudo apt-get -y --force-yes install r-base-dev; 
sudo apt-get -y --force-yes install bash bridge-utils ebtables iproute libev-dev python tcl8.5 tk8.5 libtk-img; 
sudo apt-get dist-upgrade;  sudo dpkg -i quagga-mr_0.99.21mr2.2_i386.deb; sudo apt-get -y --force-yes install quagga; sudo dpkg -i core-daemon_4.8-0ubuntu1_precise_i386.deb; sudo dpkg -i core-gui_4.8-0ubuntu1_precise_all.deb; sudo /etc/init.d/core-daemon start; 

tar -jxvf seamonkey-2.33.tar.bz2; 

sudo apt-get -y --force-yes install oracle-java8-installer; 
sudo apt-get -y --force-yes install eclipse; sudo apt-get -y --force-yes install eclipse-cdt; 
sudo apt-get -y --force-yes install  scribus-ng;

sudo apt-get -y --force-yes install nut-nutrition;

unzip /home/student/aoi.zip; 
java -jar AOI-Linux-303.jar; 
sudo apt-get -y --force-yes install avidemux;

sudo apt-get -y --force-yes install wine-el; 
mv /home/student/*.desktop /home/student/EducationSoftware"

uxterm -e "rm /home/student/.kde/Autostart/runme.sh"







