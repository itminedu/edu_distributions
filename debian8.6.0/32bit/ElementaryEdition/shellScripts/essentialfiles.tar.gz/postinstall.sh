#!/bin/sh
mkdir /home/student/assets

cp /tmp/xmind.png /home/student/assets
chown student:student /home/student/assets/xmind.png

cp /tmp/asymptopia.png /home/student/assets
chown student:student /home/student/assets/asymptopia.png

cp /tmp/lightbot.png /home/student/assets
chown student:student /home/student/assets/lightbot.png

cp /tmp/thinglink.png /home/student/assets
chown student:student /home/student/assets/thinglink.png

cp /tmp/vt.png /home/student/assets
chown student:student /home/student/assets/vt.png

cp /tmp/url.png /home/student/assets
chown student:student /home/student/assets/url.png

cp /tmp/jp.png /home/student/assets
chown student:student /home/student/assets/jp.png

cp /tmp/edu.png /home/student/assets
chown student:student /home/student/assets/edu.png

cp /tmp/tagul.png /home/student/assets
chown student:student /home/student/assets/tagul.png

cp /tmp/audacity.desktop /home/student/assets/audacity.desktop
chown student:student /home/student/assets/audacity.desktop
chmod +x /home/student/assets/audacity.desktop

cp /tmp/asymptopia.desktop /home/student/assets/asymptopia.desktop
chown student:student /home/student/assets/asymptopia.desktop
chmod +x /home/student/assets/asymptopia.desktop

cp /tmp/lightbot.desktop /home/student/assets/lightbot.desktop
chown student:student /home/student/assets/lightbot.desktop
chmod +x /home/student/assets/lightbot.desktop

cp /tmp/thinglink.desktop /home/student/assets/thinglink.desktop
chown student:student /home/student/assets/thinglink.desktop
chmod +x /home/student/assets/thinglink.desktop

cp /tmp/phet.desktop /home/student/assets/phet.desktop
chown student:student /home/student/assets/phet.desktop
chmod +x /home/student/assets/phet.desktop

cp /tmp/firefox.desktop /home/student/assets/firefox.desktop
chown student:student /home/student/assets/firefox.desktop
chmod +x /home/student/assets/firefox.desktop

cp /tmp/k3b.desktop /home/student/assets/k3b.desktop
chown student:student /home/student/assets/k3b.desktop
chmod +x /home/student/assets/k3b.desktop

cp /tmp/libreofficecalc.desktop /home/student/assets/libreofficecalc.desktop
chown student:student /home/student/assets/libreofficecalc.desktop
chmod +x /home/student/assets/libreofficecalc.desktop

cp /tmp/libreofficeimpress.desktop /home/student/assets/libreofficeimpress.desktop
chown student:student /home/student/assets/libreofficeimpress.desktop
chmod +x /home/student/assets/libreofficeimpress.desktop

cp /tmp/libreofficewriter.desktop /home/student/assets/libreofficewriter.desktop
chown student:student /home/student/assets/libreofficewriter.desktop
chmod +x /home/student/assets/libreofficewriter.desktop

cp /tmp/openshot.desktop /home/student/assets/openshot.desktop
chown student:student /home/student/assets/openshot.desktop
chmod +x /home/student/assets/openshot.desktop

cp /tmp/scratch.desktop /home/student/assets/scratch.desktop
chown student:student /home/student/assets/scratch.desktop
chmod +x /home/student/assets/scratch.desktop

cp /tmp/vlc.desktop /home/student/assets/vlc.desktop
chown student:student /home/student/assets/vlc.desktop
chmod +x /home/student/assets/vlc.desktop

cp /tmp/Xmind.desktop /home/student/assets/Xmind.desktop
chown student:student /home/student/assets/Xmind.desktop
chmod +x /home/student/assets/Xmind.desktop

cp /tmp/voki.desktop /home/student/assets/voki.desktop
chown student:student /home/student/assets/voki.desktop
chmod +x /home/student/assets/voki.desktop

cp /tmp/timeglider.desktop /home/student/assets/timeglider.desktop
chown student:student /home/student/assets/timeglider.desktop
chmod +x /home/student/assets/timeglider.desktop

cp /tmp/jigsawplanet.desktop /home/student/assets/jigsawplanet.desktop
chown student:student/home/student/assets/jigsawplanet.desktop
chmod +x /home/student/assets/jigsawplanet.desktop

cp /tmp/edubuncee.desktop /home/student/assets/edubuncee.desktop
chown student:student /home/student/assets/edubuncee.desktop
chmod +x /home/student/assets/edubuncee.desktop

cp /tmp/tagul.desktop /home/student/assets/tagul.desktop
chown student:student /home/student/assets/tagul.desktop
chmod +x /home/student/assets/tagul.desktop

cp /tmp/zunal.desktop /home/student/assets/zunal.desktop
chown student:student /home/student/assets/zunal.desktop
chmod +x /home/student/assets/zunal.desktop

cp /tmp/awwapp.desktop /home/student/assets/awwapp.desktop
chown student:student /home/student/assets/awwapp.desktop
chmod +x /home/student/assets/awwapp.desktop

cp /tmp/Home.desktop /home/student/assets/Home.desktop 
chown student:student /home/student/assets/Home.desktop 
chmod +x /home/student/assets/Home.desktop

cp /tmp/trash.desktop /home/student/assets/trash.desktop 
chown student:student /home/student/assets/trash.desktop 
chmod +x /home/student/assets/trash.desktop

echo "deb http://ppa.launchpad.net/webupd8team/java/ubuntu xenial main" | tee /etc/apt/sources.list.d/webupd8team-java.list
echo "deb-src http://ppa.launchpad.net/webupd8team/java/ubuntu xenial main" | tee -a /etc/apt/sources.list.d/webupd8team-java.list

cp /tmp/tsrepo.sh /home/student/assets
chown student:student /home/student/assets/tsrepo.sh
chmod +x /home/student/assets/tsrepo.sh

mkdir /home/student/.kde
mkdir /home/student/.kde/Autostart
chown -R student:student /home/student/.kde
chown -R student:student /home/student/.kde/Autostart
cp /home/student/runme.sh /home/student/.kde/Autostart/runme.sh
chown student:student /home/student/.kde/Autostart/runme.sh
chmod +x /home/student/.kde/Autostart/runme.sh 

mv /home/student/runme.sh /home/student/assets
mv /home/student/RunME.desktop /home/student/assets

/bin/cp -f /tmp/freedesktop.org.xml /usr/share/mime/packages/freedesktop.org.xml

pip install PyMsgBox
touch /root/elementary32
