#!/bin/sh
mkdir /home/student/EducationSoftware
mkdir /home/student/EducationSoftware/Icons
mkdir /home/student/EducationSoftware/FlashPlayer

cp /home/student/assets/Xmind.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/Xmind.desktop"

cp /home/student/assets/xmind.png /home/student/EducationSoftware/Icons/xmind.png

cp /home/student/assets/aesopos.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/aesopos.desktop"

cp /home/student/assets/asymptopia.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/asymptopia.desktop"

cp /home/student/assets/asymptopia.png /home/student/EducationSoftware/Icons/asymptopia.png


cp /home/student/assets/thinglink.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/thinglink.desktop"

cp /home/student/assets/thinglink.png /home/student/EducationSoftware/Icons/thinglink.png


cp /home/student/assets/lightbot.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/lightbot.desktop"

cp /home/student/assets/lightbot.png /home/student/EducationSoftware/Icons/lightbot.png

cp /home/student/assets/timeglider.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/timeglider.desktop"

cp /home/student/assets/photodentro.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/photodentro.desktop"

cp /home/student/assets/url.png /home/student/EducationSoftware/Icons/url.png

cp /home/student/assets/jigsawplanet.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/jigsawplanet.desktop"

cp /home/student/assets/jp.png /home/student/EducationSoftware/Icons/jp.png

cp /home/student/assets/edubuncee.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/edubuncee.desktop"

cp /home/student/assets/edu.png /home/student/EducationSoftware/Icons/edu.png

cp /home/student/assets/tagul.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/tagul.desktop"

cp /home/student/assets/tagul.png /home/student/EducationSoftware/Icons/tagul.png

cp /home/student/assets/zunal.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/zunal.desktop"

cp /home/student/assets/phet.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/phet.desktop"

cp /home/student/assets/audacity.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/audacity.desktop"

cp /home/student/assets/firefox.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/firefox.desktop"

cp /home/student/assets/k3b.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/k3b.desktop"

cp /home/student/assets/libreofficecalc.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/libreofficecalc.desktop"

cp /home/student/assets/libreofficeimpress.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/libreofficeimpress.desktop"

cp /home/student/assets/libreofficewriter.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/libreofficewriter.desktop"

cp /home/student/assets/openshot.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/openshot.desktop"

cp /home/student/assets/scratch.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/scratch.desktop"

cp /home/student/assets/vlc.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/vlc.desktop"

cp /home/student/assets/Home.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/Home.desktop"

cp /home/student/assets/trash.desktop "/home/student/Επιφάνεια εργασίας"
chmod +x "/home/student/Επιφάνεια εργασίας/trash.desktop"

uxterm -e "wget -O /home/student/EducationSoftware/FlashPlayer/flash_player_npapi_linux.i386.tar.gz http://ostdev.minedu.gov.gr/~sofiakom/customDistros/HighSchoolEdition/flash_player_npapi_linux.i386.tar.gz ; tar xvf /home/student/EducationSoftware/FlashPlayer/flash_player_npapi_linux.i386.tar.gz -C  /home/student/EducationSoftware/FlashPlayer ; sudo cp /home/student/EducationSoftware/FlashPlayer/libflashplayer.so /usr/lib/mozilla/plugins ; sudo cp -r /home/student/EducationSoftware/FlashPlayer/usr/* /usr ; wget -O /home/student/EducationSoftware/xmind-8-linux.zip http://ostdev.minedu.gov.gr/~pgeorg/customDistros/ElementaryEdition/xmind-8-linux.zip ; unzip -o /home/student/EducationSoftware/xmind-8-linux.zip -d /home/student/EducationSoftware/Xmind ; sudo /home/student/EducationSoftware/Xmind/setup.sh ; wget -O /home/student/EducationSoftware/AsymptopiaXW-3.2.zip http://ostdev.minedu.gov.gr/~sofiakom/customDistros/ElementaryEdition/AsymptopiaXW-3.2.zip ; unzip -o /home/student/EducationSoftware/AsymptopiaXW-3.2.zip -d /home/student/EducationSoftware/AsymptopiaXW ; sudo apt-get update ; sudo apt-get -y --force-yes install oracle-java8-installer ; wget -O /home/student/EducationSoftware/java3d-1_5_1-linux-i586.bin http://ostdev.minedu.gov.gr/~sofiakom/customDistros/ElementaryEdition/java3d-1_5_1-linux-i586.bin ; cd /usr/lib/jvm/java-8-oracle/jre ; sudo sh /home/student/EducationSoftware/java3d-1_5_1-linux-i586.bin ; cd ; sudo cp /home/student/assets/java.policy /etc/java-8-oracle/security/java.policy ; sudo cp -f /home/student/assets/exception.sites /home/student/.java/deployment/security/exception.sites ; sudo /home/student/assets/tsrepo.sh ; sudo apt-get -y --force-yes install wine-el ; sudo apt-get -y --force-yes install dimotiko ; sudo apt-get -y --force-yes install dimotiko-extra ; sudo apt-get -y --force-yes install dim-anakalypto-ton-kosmo-mesa-apo-ton-ypologisti ; sudo apt-get -y --force-yes install dim-mathaino-ti-glossa-mou ; sudo apt-get -y --force-yes install dim-perivallon-i-prostasia-tou-dasous ; sudo apt-get -y --force-yes install dim-sto-stavrodromi-trion-ipeiron-i-zoi-sti-vyzantini-aftokratoria ; sudo apt-get -y --force-yes install dim-politika-kai-diplomatika-gegonota-tis-neoteris-istorias-mas ; mkdir /home/student/.java ;  mkdir /home/student/.java/deployment ; mkdir /home/student/.java/deployment/security ; sudo cp /home/student/assets/exception.sites /home/student/.java/deployment/security/exception.sites ; rm /home/student/.kde/Autostart/runme.sh"



