#!/bin/sh

mkdir /home/student/InitialFiles ; \

cp /tmp/lightbot-icon-152jr.png /home/student/InitialFiles ; \ 
cp /tmp/xmind.png /home/student/InitialFiles ; \ 
cp /tmp/asymptopia.png /home/student/InitialFiles ; \
cp /tmp/url.png /home/student/InitialFiles ; \

cp /tmp/timeglider.desktop /home/student/InitialFiles/timeglider.desktop ; \
cp /tmp/zunal.desktop /home/student/InitialFiles/zunal.desktop ; \
cp /tmp/phet.desktop /home/student/InitialFiles/phet.desktop ; \
cp /tmp/asymptopia.desktop /home/student/InitialFiles/asymptopia.desktop ; \
cp /tmp/Xmind.desktop /home/student/InitialFiles/Xmind.desktop ; \
cp /tmp/libreofficewriter.desktop /home/student/InitialFiles/libreofficewriter.desktop ; \
cp /tmp/libreofficecalc.desktop /home/student/InitialFiles/libreofficecalc.desktop ; \
cp /tmp/vlc.desktop /home/student/InitialFiles/vlc.desktop ; \
cp /tmp/filezilla.desktop /home/student/InitialFiles/filezilla.desktop ; \
cp /tmp/firefox.desktop /home/student/InitialFiles/firefox.desktop ; \
cp /tmp/audacity.desktop /home/student/InitialFiles/audacity.desktop ; \
cp /tmp/openshot.desktop /home/student/InitialFiles/openshot.desktop ; \
cp /tmp/k3b.desktop /home/student/InitialFiles/k3b.desktop ; \
cp /tmp/lightbot.desktop /home/student/InitialFiles/lightbot.desktop ; \
cp /tmp/Home.desktop /home/student/InitialFiles/Home.desktop ; \
cp /tmp/trash.desktop /home/student/InitialFiles/trash.desktop ; \

chown student:student /home/student/InitialFiles/lightbot-icon-152jr.png ; \
chown student:student /home/student/InitialFiles/xmind.png ; \
chown student:student /home/student/InitialFiles/asymptopia.png ; \
chown student:student /home/student/InitialFiles/url.png ; \

chown student:student /home/student/InitialFiles/timeglider.desktop ; \
chown student:student /home/student/InitialFiles/zunal.desktop ; \
chown student:student /home/student/InitialFiles/phet.desktop ; \
chown student:student /home/student/InitialFiles/asymptopia.desktop ; \
chown student:student /home/student/InitialFiles/Xmind.desktop ; \
chown student:student /home/student/InitialFiles/libreofficewriter.desktop ; \
chown student:student /home/student/InitialFiles/libreofficecalc.desktop ; \
chown student:student /home/student/InitialFiles/vlc.desktop ; \
chown student:student /home/student/InitialFiles/filezilla.desktop ; \
chown student:student /home/student/InitialFiles/firefox.desktop ; \
chown student:student /home/student/InitialFiles/audacity.desktop ; \
chown student:student /home/student/InitialFiles/openshot.desktop ; \
chown student:student /home/student/InitialFiles/k3b.desktop ; \
chown student:student /home/student/InitialFiles/lightbot.desktop ; \
chown student:student /home/student/InitialFiles/Home.desktop ; \
chown student:student /home/student/InitialFiles/trash.desktop ; \
  
chmod +x /home/student/InitialFiles/*.desktop ; \

echo "deb http://ppa.launchpad.net/webupd8team/java/ubuntu xenial main" | tee /etc/apt/sources.list.d/webupd8team-java.list ; \
echo "deb-src http://ppa.launchpad.net/webupd8team/java/ubuntu xenial main" | tee -a /etc/apt/sources.list.d/webupd8team-java.list ; \

cp /tmp/tsrepo.sh /home/student/InitialFiles ; \
chown student:student /home/student/InitialFiles/tsrepo.sh ; \
chmod +x /home/student/InitialFiles/tsrepo.sh ; \

mkdir /home/student/.kde ; \
mkdir /home/student/.kde/Autostart ; \
chown -R student:student /home/student/.kde ; \
cp /home/student/runme.sh /home/student/.kde/Autostart ; \
chown student:student /home/student/.kde/Autostart/runme.sh ; \
chmod +x /home/student/.kde/Autostart/runme.sh ; \

mv /home/student/runme.sh /home/student/InitialFiles ; \
mv /home/student/RunME.desktop /home/student/InitialFiles ; \

chown student:student /home/student/InitialFiles/runme.sh ; \
chown student:student /home/student/InitialFiles/RunME.desktop ; \

/bin/cp -f /tmp/freedesktop.org.xml /usr/share/mime/packages/freedesktop.org.xml ; \

pip install PyMsgBox

touch /root/juniorhighschool32
